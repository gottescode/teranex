=== WS Facebook Like Box Widget ===
Contributors: webshouters
Tags: facebook, facebook like, likebox, widget, likebox, custom facebook likebox, facebook, facebook badge, facebook button, facebook like, facebook like box, facebook like box shortcode, facebook like box shortcodes, facebook like box widget, facebook like button, Facebook like widget, facebook likebox, facebook likebox widget, facebook meta, facebook meta tag, Facebook Open Graph, Facebook Page, facebook platform, facebook plugin, facebook recommend, facebook share, facebook sidebar, facebook style, facebook wall, Facebook Widget, friends, google +1, google plus, Like, like box, like box facebook, like box sidebox, like box widget, likebox, meta, nice facebook like box, open graph, page, plugin, seo, sharebar, sidebar, social, Social Plugins, social profiles, social share, shortcode, social sidebar, wordpress facebook like box, wordpress like
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CCSEKJQGBQTEQ
Requires at least: 4.4
Tested up to: 4.6
Stable tag: 2.4.3
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin provides easy and quick use facebook like box widget in your blog. You can fully customize facebook like box in easy way. 
 
== Description == 

WS Facebook Like Box Widget provides easy and quick use facebook like box widget in your blog. You can fully customize facebook like box in easy way.

A Facebook Like Box Widget is a social plugin that enables Facebook Page owners to attract and gain Likes & Recommendation Comments from their own website.

<strong>Free Features</strong> 


* Easy to install and Configure
* User friendly and easy to use.
* All browser working
* No facebook api key required
* Fully customized layout
* Show latest post from facebook page
* Show Events from facebook page
* Send Message
* Change Like Box Width
* Change Like Box Height
* Show/hide Friend's Faces
* Use Small Header
* Show/hide Cover Photo
* Change Like Box language
* Easy to add shortcode anywhere in your wordpress site.

<strong>Shortcode</strong>

>[ws-facebook-likebox page_id="webshouters" width="340" height="500" small_header="no" hide_cover_photo="no" show_faces="no" tabs="timeline"]
    
**Live Demo**
 
[https://www.webshouters.com/ws-facebook-like-box-pro/](https://www.webshouters.com/ws-facebook-like-box-pro/ "Click to Live Demo")

If you want more information about this plugin or another one don't doubt to visit our website:

[https://www.webshouters.com/](https://www.webshouters.com/ "WebShouters")

= Technical Support =

If any problem occurs, please contact us at [support@webshouters.com](mailto:support@webshouters.com).

== Installation ==

This section describes how to install the plugin and get it working.

1. Download [WS Facebook Like Box Widget](https://wordpress.org/plugins/ws-fecebook-likebox/) plugin.   
2. Upload the "WS Facebook Like Box" plugin from your admin panel.    
3. Activate the "WS Facebook Like Box"  plugin. 
4. Add "WS Facebook Like Box widget" to your sidebar.    

== Frequently Asked Questions ==

Please visit the forum for questions or comments: https://wordpress.org/support/plugin/ws-facebook-likebox

== Screenshots ==

1. This screenshots for widget settings.
2. Using shortcode on page.
3. Screenshot for facebook likebox(default).
4. Screenshot for facebook likebox(Tabs-Hide Posts).
5. Screenshot for facebook likebox without posts.

== Changelog ==

= 4.1 =

* Fix plugin notices
* Fix errors notices
* Update informations

= 4.0 =

* Fix plugin notices
* Fix errors notices
* Update informations

= 3.2 =

* Publish pro version
* Modify Languages

= 3.1 =

* Internationalize plugin
* Make translatable plugin
* Update Language Support

= 3.0 =

* Update with latest facebook sdk
* Language Support
* Show or Hide Posts, Events & Send Message
* Use Small Header
* Show/hide Cover Photo
* Update Shortcode

== Upgrade Notice ==

Upgrade to Version 4.1.
