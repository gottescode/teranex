  

<div class="container">
<div class="col-sm-offset-2 col-sm-8">
	<center>
		<h1>Consultant Availability</h1>
	</center>
	<h3 class="p-strong">Your remote service engineer Amit Das will be available to start teleservice at 11:00am on 5th July 2017.</h3>
<div class=" mar-20-btm full-width pull-left">
	<div class="col-sm-6">
		<button class="btn input-form adv-search form-control" />Request Later Time</button>
	</div>
	<div class="col-sm-6">
		<button class="btn input-form confrm form-control" />Confirm</button>
	</div>
</div>
</div>
</div>
 