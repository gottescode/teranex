
<div class="content-wrapper">
   

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box box-primary">
            
	<?php $this->load->view("_form",array("action" => "create_forum"));	?>
		</div>
	  </div>
	</div>
	</section>
</div> 


					
					
				