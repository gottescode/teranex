<table cellspacing="0" cellpadding="1" border="0">
    <tr>
        <td><b>Sold By :</b></td>
        <td style="text-align: right;"><b>Billing Adddress :</b></td>
    </tr>
    <tr>
    	<td>GBD Retail LLP<br/>Room No-3, Shree Seth Chawl, Ambechi Bhami,<br/>Tulsipada Pipe Line, Gaondevi Road, Bhandup West,<br/>Mumbai, Maharashtra, 400078 <br/>IN</td>
    	<td style="text-align: right;">Atul Mangave<br/>B/302, Oxford Hallmark,Lane 7, Koregaon Park,<br/>Pune, Maharashtra, 411001<br/> IN</td>
    </tr>
    <br/>
    <tr>
        <td><b>PAN No :</b> AAFCG7444Q</td>
        <td style="text-align: right;"><b>Shipping Adddress :</b></td>
    </tr>
    <tr>
        <td><b>GST Registration No :</b> 27AAFCG7444Q1ZW</td>
        <td style="text-align: right;">Atul Mangave<br/>B/302, Oxford Hallmark,Lane 7, Koregaon Park,<br/>Pune, Maharashtra, 411001<br/> IN</td>
    </tr>
    <tr>
        <td><b>Order Number :</b> 408-9253080-3479529</td>
        <td style="text-align: right;"><b>Invoice Number :</b> IN-126025</td>
    </tr>
    <tr>
        <td><b>Order Date :</b> 26.03.2018</td>
        <td style="text-align: right;"><b>Invoice Details :</b> MH-147384671-1718</td>
    </tr>
    <tr>
        <td></td>
        <td style="text-align: right;"><b>Invoice Date :</b> 26.03.2018</td>
    </tr>
</table>
<br/><br/><br/>
<table cellspacing="0" cellpadding="1" border="1">
    <tr>
        <td> SI No </td>
        <td> Description </td>
        <td> Unit Price </td>
        <td> Qty </td>
        <td> Net Amount </td>
        <td> Tax Rate </td>
        <td> Tax Type </td>
        <td> Tax Amount </td>
        <td> Total Amount </td>
    </tr>
    <tr>
        <td> 1 </td>
        <td> Graco Blossom 4-in-1 Seating System,Vance | B005XJ2VGE (7210837) </td>
        <td> &#8377; 26,489.28 </td>
        <td> 1 </td>
        <td> &#8377; 26,489.28 </td>
        <td> 6% <br/> 6% </td>
        <td> CGST <br/> SGST </td>
        <td> &#8377; 1,589.36 <br/> &#8377; 1,589.36 </td>
        <td> &#8377; 29,668.00 </td>
    </tr>
    <tr>
       <td colspan="7"><b> Total : </b></td>
       <td> &#8377; 3,178.72 </td>
       <td> &#8377; 29,668.00 </td>
    </tr>
    <tr>
    	<td colspan="9"><b> Amount in Words : </b><br/> Twenty-nine Thousand Six hundred and Sixty-eight only </td>
    </tr>
    <tr>
    	<td colspan="9" style="text-align: right;"><b> For GBD Retail LLP : </b><br/><br/> Authorized Signatory </td>
    </tr>

</table>