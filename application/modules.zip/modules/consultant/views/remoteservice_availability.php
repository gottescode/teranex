<div class="container">
	<div class="col-sm-offset-1 col-sm-10">
		<div class="">
			<center><h2>Remote Service Engineer Availability</h2></center>
		
			<div class="gray-bg">
				<p>Your remote service engineer Amit Das will be available to start teleservice at 11:00 am to 5<sup>th</sup> July 2017.</p>
			</div><br/>
			 
				<center><a href="" class="btn btn-primary btn_blue">Request Later Date</a><a href="" class="btn btn_orange">Confirm</a></center>
			<br/>
			<p>* Please sign in to my Stelmac go to Dashboard, and select Remote service on the date and time specified above.</p>
		</div>
	</div>
</div>