  <style>
      .mar-tb-20 {
    margin-top: 20px;
    margin-bottom: 20px;
}
video {
    display: inline-block;
    vertical-align: baseline;
    object-fit: unset;
    width: 396px;
    }
    .fg_span {
    margin-bottom: 30px;
    float: left;
    width: 100%;
}
h3.vconf {
    margin-bottom: 30px;
    margin-top: -2px;
}
.videobtn{
	margin-top:57px;
	width:100%;
	float:left;
}
.videosize {
    margin-top: 5px;
    height: 243px;
}
  </style>
  
<div class="" style="margin-top: 69px;"><img class="img-responsive bnr-images" src="<?php echo $theme_url?>/images/machine-breakdown1.jpg" width="100%"></div>
  	<div class="col-sm-12 box-padd padd-0">
		<div class="" style="padding: 0 !important;">
			<div class="container-fluid myprofile-bg dahboard-bg">
			  <div class="container">
			    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padd-0">
			      <center><h2 class="margin-0">Service Engineers</h2></center>
			    </div>
			  </div> 
			</div>
			<div class="container-fluid programmers-grey-bg">
			  	<div class="container">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padd-0">
					    <form action="" method="post">
							<div class="col-sm-3 col-md-3 padd-0">
								<!-- <div class="form-group advanced-marg">
									<label for="inputEmail3" class="col-sm-4 sort-by padd-0">Sort by:</label>
									<div class="col-sm-8 padd-0">
										<select name="language" class="form-control input-form ">
											<?php if($language_list){
												foreach($language_list as $rowLang){?>
												<option value="<?php echo $rowLang['lid'];?>"><?php echo $rowLang['name'];?></option> 
											<?php }}?>
										</select>
									</div>
								</div> -->
							</div>
							<div class="col-sm-4 col-md-4">
								<div class="col-sm-12 input-group">
									<input type="text" class="form-control input-form search-go" placeholder="Search" name="programerName">
									<div class="input-group-btn">
										<button class="btn btn-default search-go" type="submit" name="btnSearch"><span>Go</span></button>
									</div>
								</div>
							</div>
					    </form>
				     	<div class="col-sm-2 col-md-2"> 
				     		 <!-- <a href="" class="btn btn_orange" data-toggle="modal" data-target="#advsearchmodal"><span class="advanced-search">Advanced Search</span></a> -->
				     	</div>
					    <div class="col-sm-3 col-md-3 sortby-marg padd-0">
					     	<p class="pull-right"><span class="one-ten-text"><?php echo $pageintation['start']?> - <?php echo $pageintation['end']?></span> of <?php echo $pageintation['totalCount'];?> Service Engineers</p>
					    </div>
				    </div>
			 	</div>
			</div>
		</div>
		<br/>
<?php 	 // display messages

	if(hasFlash("dataMsgSuccess"))	{	?>

		<div class="alert alert-success alert-dismissible" role="alert">

		  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>

		  <?php echo getFlash("dataMsgSuccess"); ?>

		</div>

<?php	}	?>

<?php 	// display messages

	if(hasFlash("dataMsgError"))	{	?>

		<div class="alert alert-warning alert-dismissible" role="alert">

		  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>

		  <?php echo getFlash("dataMsgError"); ?>

		</div>

<?php	}	?>
		<div class="container sq-tiles">
			<div class="col-sm-12 padd-0">
		    	<center><h2>Remote Machine Service</h2>
				<p>At Stelmac, we provide live online consulting for business development etc.</p></center>
				<div class="col-sm-4 col-xs-12 padd-8 ">
					<!-- <?php if($this->session->userdata('uid')==''){?>
						<a href="#" data-toggle="modal" data-target="#signinModal">
					<?php }else{?>
						<a href="#" data-toggle="modal" data-target="#ondemandser_modal">
					<?php }?> -->
					<div class=" dad">
					  	<div class="son-1" style="background-image: url('<?php echo $theme_url?>/images/remoteappconsult-min.jpg');"></div>
				    	<div class="son-text">
							<h3>Machine Breakdown</h3>
							<p>With reliable and fast reaction time for a machine breakdown, we ensure high availability and smooth functioning of a machine even under the most demanding situations. </p>
							<?php if($this->session->userdata('uid')==''){?>
								<a href="#" data-toggle="modal" data-target="#signinModal">
							<?php }else{?>
								<a href="#" data-toggle="modal" data-target="#ondemandser_modal">
							<?php }?>View More >></a>
						</div>
					</div>
					<!-- </a> -->
		        </div>

		        <div class="col-sm-4 col-xs-12 padd-8">
					<!-- <?php if($this->session->userdata('uid')==''){?>
						<a href="#" data-toggle="modal" data-target="#signinModal">
					<?php }else{?>
						<a href="#" data-toggle="modal" data-target="#ondemandser_modal">
					<?php }?> -->
					<div class=" dad">
					  	<div class="son-1" style="background-image: url('<?php echo $theme_url?>/images/machine-maintenance-min.jpg');"></div>
				    	<div class="son-text">
							<h3>Machine Maintenance</h3>
							<p>Designed to improve the productivity of a machine while preventing any issues in advance, maintenance schedules ensure high availability and productivity of a machine.</p>
							<?php if($this->session->userdata('uid')==''){?>
						<a href="#" data-toggle="modal" data-target="#signinModal">
					<?php }else{?>
						<a href="#" data-toggle="modal" data-target="#ondemandser_modal">
					<?php }?> View More >></a>
						</div>
					</div>
					<!-- </a> -->
		        </div>

		        <div class="col-sm-4 col-xs-12 padd-8">
					<!-- <?php if($this->session->userdata('uid')==''){?>
						<a href="#" data-toggle="modal" data-target="#signinModal">
					<?php }else{?>
						<a href="#" data-toggle="modal" data-target="#serviceagreement_modal">
					<?php }?> -->
					<div class=" dad">
					  	<div class="son-1" style="background-image: url('<?php echo $theme_url?>/images/service-agreement-min.jpg');"></div>
				    	<div class="son-text">
							<h3>Service Agreement</h3>
							<p>Whether attending your machine personally on site or via remote service, Stelmac highly qualified service engineers are available for installation, diagnosis, repair or maintenance. </p>
							<?php if($this->session->userdata('uid')==''){?>
						<a href="#" data-toggle="modal" data-target="#signinModal">
					<?php }else{?>
						<a href="#" data-toggle="modal" data-target="#serviceagreement_modal">
					<?php }?> View More >></a>
						</div>
					</div>
					<!-- </a> -->
		        </div>
		   	</div>
		</div>
	</div>
<div class="clearfix"></div>
<div class="container-fliud">
		<div class="container">
	  		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padd-0">
	  			<h2 style="margin-top: 0;" class="col-sm-12 text-center">Meet Our Service Engineers</h2>
				<div class="">
					<ul class="cadcam1">
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>	
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>
						<li id="" >
							<div class="col-sm-12 col-md-12 padd-8">
								<div class="prgrmr amit-border">
									<div class="amit_img_bag">
										<img src="<?php echo $theme_url?>/images/krishna.PNG">							
									</div>
									<div class="amit-text">
										<span class="amit-das-text">david</span>
										<p>Certified Public Bookkeeper</p>
										<!--<span class="certified">Certified Public Bookkeeper</span>-->
										<div class="prgrmr_det">
											<p><span class="left_label">Rate</span> <span class="pull-right"><span style="font-size: 16px;font-weight: bold;">₹ 550</span>/hr</span></p>
											<p><span class="left_label">Location</span> <span class="pull-right"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp;India</span></p>
											<p></p>
											<div class="clearfix"></div>
										</div>
										<div class="clearfix"></div>
										<a href=""><button class="btn btn-default addmore-btn">View Profile </button></a>
									</div>
								</div>
							</div>
						</li>
					</ul> 
				</div>
			</div>
			<nav aria-label="...">
			 <?php echo pagination($pageintation['totalCount'],$pageintation['page'],$pageintation['show'],site_url()."remoteprogramming/index/",'');?>		
			</nav>
		</div> 
		<div class="clearfix"></div>
		
	</div>  
	 	
	
<div class="clearfix"></div><br/>
<div style="background: #f9f9f9;">
	<div class="container">
		<div class="col-sm-12 padd-8">
			<div class="full-width pull-left mar-tb-20" id="">
				<div class="pull-left full-width">
						<center><h2 style="margin-top: 0;">Chat with Us </h2></center>
					<div class="col-sm-offset-2 col-sm-4 padd-0">
						<form role="form" action="" id="videoconference" method="post" enctype="multipart/form-data">
							<h3 class="vconf">What would you like to do?</h3>
							<div class="form-group">
								<span class="fg_span"><input type="radio" value="T" name="video_chat" checked> Text chat with a Service Engineers</span><br/>
								<span class="fg_span"><input type="radio" value="V" name="video_chat"> Video chat with a Service Engineers</span><br/>
								<!--<span class="fg_span"><input type="radio" value="B" name="video_chat"> Video chat with a Teranex Programmer</span><br/>-->
							</div>
							<div class="videobtn">
								<?php
								if($this->session->userdata('uid')==''){ ?>
								<input type="button"  data-toggle="modal" data-target="#signinModal" class="btn btn_orange pull-left" value="Submit" />
								<?php }else{?>
								<input type="submit" name="btnVideoRequest" class="btn btn_orange pull-left" value="Submit" id="submitrequest" data-custom="<?php echo $this->session->userdata('uid'); ?>" />
								<?php }?>
							</div>
						</form>
					</div>
					<div class="col-sm-4 padd-0">
						<div class="T chatbox" style="margin-top: 8px;">
							<form role="form" action="" id="contactEnquiry" method="post" enctype="multipart/form-data">
							<!-- <?php
								if($user_id==''){ echo "<h3 style='margin-top: 23px; float:right;'>Please login before submit request. <a class='orng_clr' href='#'  data-toggle='modal' data-target='#signinModal'>Click Here</a></h3> ";}?> -->
								<div class="form-group">
								   <textarea class="form-control required" name="message" id="message" placeholder="Write here.." rows="9"> </textarea>
								</div>
								<div>
								<?php
									if($user_id==''){ ?>
									<input type="button"  data-toggle="modal" data-target="#signinModal" class="btn btn_orange pull-right" value="Send"/>
									<?php }else{?>
									<input type="submit" name="btnContactEnquiry" class="btn btn_orange pull-right" value="Send"/>
									<?php }?>
								</div>
							</form>
						</div>
<!--						<div class="V chatbox" style="display: none;">
							<video controls class="pull-right videosize" >
							  	<source src="<?php echo $theme_url?>/images/sample-video.mp4" type="video/mp4">
							  	<source src="<?php echo $theme_url?>/images/sample-video.ogg" type="video/ogg">
							  	Your browser does not support the video tag.
							</video>
						</div>
						<div class="B chatbox" style="display: none;">
							<video controls class="pull-right videosize" >
							  	<source src="<?php echo $theme_url?>/images/sample-video.mp4" type="video/mp4">
							  	<source src="<?php echo $theme_url?>/images/sample-video.ogg" type="video/ogg">
							  	Your browser does not support the video tag.
							</video>
						</div>-->
					</div>
				</div>
			</div>
		</div><div class="clearfix"></div>
	</div>
</div>
<div class="clearfix"></div><br/>
<div class="container-fliud r-programming recent-view">
		<div class="container">
			<center><h2>Recently Viewed</h2></center>
			<ul class="cadcam">
			<li>
				  	<a class="thumbnail" href="https://www.teranex.io/beta-V*SRJ!-452656-230718/consultant/expert/consultantDetail/9">
						<img alt="" src="<?php echo $theme_url?>/images/trainers-img1.jpg">
						<div class="amit-text text-center">
							<span class="amit-das-text">Elle</span>
							<span class="certified">Certified Public Bookkeeper</span>
						</div>
					</a>
				</li>
				<li>
				  	<a class="thumbnail" href="https://www.teranex.io/beta-V*SRJ!-452656-230718/consultant/expert/consultantDetail/11">
						<img alt="" src="<?php echo $theme_url?>/images/trainers-img1.jpg">
						<div class="amit-text text-center">
							<span class="amit-das-text">justinn</span>
							<span class="certified">Certified Public Bookkeeper</span>
						</div>
					</a>
				</li>
			
				<li>
				  	<a class="thumbnail" href="<?php echo site_url()."consultant/expert/consultantDetail/".$row['uid'];?>">
						<img alt="" src="<?php echo $theme_url?>/images/trainers-img1.jpg">
						<div class="amit-text text-center">
							<span class="amit-das-text">Atul</span>
							<span class="certified">Certified Public Bookkeeper</span>
						</div>
					</a>
				</li>
			
		  	</ul>     
		</div>
	</div>
<div class="clearfix"></div>
<!-- <div class="container">
	<div class="col-sm-12 padd-0">
		<center><h2>Service Engineers Featured This Month</h2></center>
		<div class="last-sec">
			<div class="col-sm-2 col-md-1 padd-0">
				<img src="<?php echo $theme_url?>/images/trainers-img1.jpg" class="img-responsive" style="border-radius: 50%;height: 70px;width: 70px;">
			</div>
			<div class="col-sm-10 col-md-11 padd-0">
				<p>Emma is an energetic and passionate leader, technologist, and consultant with over 10 years of strategic planning, tactical centered implementation, and management consulting experience. Joshua utilizes proven qualitative and analytical skills driven by business objectives and up to date technology.</p>
			</div>
		</div>
	</div>
</div> -->
<div class="clearfix"></div><br/>
	<!-- Modal -->

<div id="ondemandser_modal" class="modal fade" role="dialog">
  	<div class="modal-dialog modal-sm">
	    <!-- Modal content-->
	    <div class="modal-content">
	      	<div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <center><h4 class="modal-title">On-Demand Service</h4></center>
	      	</div>
	      	<div class="modal-body">
		      	<div class="col-sm-12 border_bot">
	  				<form class="col-sm-12 form-horizontal" name="#" id="ondemand_form" method="post" action="">
						<div class="form-group ">
							<input type="text" class="form_bor_bot" id="companyname" name="company_name" value= "" placeholder="Company name" required><span class="compulsary">*</span>
						</div>
						<div class="form-group">
						  	<input type="text" class="form_bor_bot" id="machinebrand" name="machinebrand" value= "" placeholder="Machnine Brand" required><span class="compulsary">*</span>
						</div>
						<div class="form-group">
						  	<input type="text" class="form_bor_bot" id="machinetype" name="machinetype" value= "" placeholder="Machnine Type" required><span class="compulsary">*</span>
						</div>
						<div class="form-group">
						  	<input type="text" class="form_bor_bot" id="machinemodel" name="machinemodel" value= "" placeholder="Machnine Model" required><span class="compulsary">*</span>
						</div>
						<div class="form-group">
						  	<input type="text" class="form_bor_bot numbersOnly" id="machineage" name="machineage" value= "" placeholder="Age of Machnine " required><span class="compulsary">*</span>
						</div>
					  	<div class="form-group ">
					  		<select class="form_bor_bot" id="servicetype" name="servicetype">
					  			<option value="">Select Service Type</option>
					  			<option value="Machine Breakdown">Machine Breakdown</option>
					  			<option value="Machine Maintenance">Machine Maintenance</option>
					  		</select>
					  	</div>
					  	<br/>
					  	<div class="form-group">
							<div class="">
								<input type="submit" name="btnOnDemandService" id="btnOnDemandService" class="btn btn_orange" value="Service Request" style="width:100% " />
							</div>
					  	</div>
					</form>
		      	</div><div class="clearfix"></div>
	      	</div>
	    </div>
  	</div>
</div>



<!-- serviceagreement_modal -->

<div id="serviceagreement_modal" class="modal fade" role="dialog">
  	<div class="modal-dialog modal-sm">
	    <!-- Modal content-->
	    <div class="modal-content">
	      	<div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <center><h4 class="modal-title">Service Agreement</h4></center>
	      	</div>
	      	<div class="modal-body">
		      	<div class="col-sm-12 border_bot">
		  			<form class="col-sm-12 form-horizontal" name="service_agreement_form" id="service_agreement_form" method="post" action="<?php echo site_url().'consultant/request_service_support'?>">
							<div class="form-group ">
								<input type="text" class="form_bor_bot" id="company_name" name="company_name" value= "" placeholder="Company name" required><span class="compulsary">*</span>
							</div>
							<div class="form-group">
							  	<input type="text" class="form_bor_bot" id="machine_model_no" name="machine_model_no" value= "" placeholder="Machine Model ID" required><span class="compulsary">*</span>
							</div>
						  	<div class="form-group ">
						  		<select class="form_bor_bot" id="service_type" name="service_type">
						  			<option value="">Select Service Type</option>
						  			<option value="Machine Breakdown">Machine Breakdown</option>
						  			<option value="Machine Maintenance">Machine Maintainence</option>
						  			<option value="Service Agreement">Service Agreement</option>
						  			<option value="On-Demand Service">On-Demand Service</option>
						  		</select><span class="compulsary">*</span>
						  	</div>
							<div class="form-group">
							  	<textarea type="text" class="form_bor_bot" name="problem_note" id="problem_note" placeholder="Nature of problem"></textarea><span class="compulsary">*</span>
							</div><br/>
							<div class="form-group">
								<div class="">
									<input type="submit" name="btnRequest" id="submit" class="btn btn_orange" value="Service Request" style="width: 100%"> 
									<!-- <input type="submit" name="" id="submit" class="btn btn_orange" value="Service Request" style="width: 100%" /> -->
								</div>
							</div>
					</form>
		      	</div><div class="clearfix"></div>
	      	</div>
	    </div>
  	</div>
</div>



<?php $this->template->contentBegin(POS_BOTTOM);?>

<script language="javascript" type="text/javascript">

jQuery('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9\.]/g,'');
});
	
$(document).ready(function(){
    $('input[type="radio"]').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".chatbox").not(targetBox).hide();
        $(targetBox).show();
    });
});


$(document).ready()

	$("#service_agreement_form").validate({ 

            rules: {

				company_name:{

                	required: true

                }, 

				machine_model_no:{

                	required: true

                },

				service_type:{

                	required: true

                },

				problem_note:{

                	required: true

                },

            },

			messages: { 

				company_name:{

                	required: "Please enter company name"

                }, 

				machine_model_no:{

                	required: "Please enter machine model id"

                },

				service_type:{

                	required: "Please select service type"

                },

				problem_note:{

                	required: "Please enter nature of problem"

                },		

			}

	}); 



	//on demand service 

	$("#ondemand_form").validate({ 

            rules: {

				companyname:{

                	required: true

                }, 

				machinebrand:{

                	required: true

                },

				machinetype:{

                	required: true

                },

				machinemodel:{

                	required: true

                },

                machineage:{

                	required:true

                },

                servicetype:{

                	required:true

                },

            },

			messages: { 

				companyname:{

                	required: "Please enter company name"

                }, 

				machinebrand:{

                	required: "Please enter machine brand"

                },

				machinetype:{

                	required: "Please enter machine type"

                },

				machinemodel:{

                	required: "Please enter machine model"

                },

                machineage:{

                	required:"Please enter age of machine"

                },

                servicetype:{

                	required:"Please select service type"

                },

				servicetype:{

                	required: "Please select service type"

                },	

			}

	}); 

</script>
<script  src="<?php echo $theme_url;?>/js/jquery.flexisel.js"></script>
<script type="text/javascript">
	$('.cadcam1').each(function(){
	$(this).flexisel({
		visibleItems: 4,
		itemsToScroll: 1,         
		autoPlay: {
			enable: false,
			interval: 5000,
			pauseOnHover: true
		},
		responsiveBreakpoints: { 
			portrait: { 
				changePoint:480,
				visibleItems: 1,
				itemsToScroll: 1
			}, 
			landscape: { 
				changePoint:639,
				visibleItems: 2,
				itemsToScroll: 2
			},
			tablet: { 
				changePoint:769,
				visibleItems: 3,
				itemsToScroll: 3
			}
		}				
	});
});
$('.cadcam').each(function(){
	$(this).flexisel({
		visibleItems: 6,
		itemsToScroll: 1,         
		autoPlay: {
			enable: false,
			interval: 5000,
			pauseOnHover: true
		},
		responsiveBreakpoints: { 
			portrait: { 
				changePoint:480,
				visibleItems: 1,
				itemsToScroll: 1
			}, 
			landscape: { 
				changePoint:639,
				visibleItems: 3,
				itemsToScroll: 3
			},
			tablet: { 
				changePoint:769,
				visibleItems: 4,
				itemsToScroll: 4
			}
		}				
	});
});

     // video chat onclick function

    $("#submitrequest").click(function () {
        var customAttr = $(this).attr("data-custom");
        var radioBoxValue = $("input[name='video_chat']:checked").val();
        if (radioBoxValue == "V") {

            window.open("<?php echo site_url(); ?>/welcome/opentok", "_blank");


        }
    });
</script>

<?php echo $this->template->contentEnd();?> 