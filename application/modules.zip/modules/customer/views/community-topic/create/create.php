
<div class="content-wrapper">
    

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box box-primary">
            <div class="box-header">
            </div>
				<?php $this->load->view("_form",array("action" => "community_topic"));	?>
		</div>
	  </div>
	</div>
	</section>
</div> 


					
					
				