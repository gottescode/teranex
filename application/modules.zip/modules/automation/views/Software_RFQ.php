<div class="container">
	<div class="col-sm-12">
				<h2 class="text-center">Request a Quote</h2>
		<div class="col-sm-offset-2 col-sm-8">
			 <form class="form-signin form-horizontal" name="softwareRFQ" id="softwareRFQ" method="post" action="#">
				<div class="form-group">
					<label class="control-label col-sm-3" for="Fname">First Name :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot" id="Fname" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="Lname">Last Name :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot " id="Lname" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="email">Email :</label>
					<div class="col-sm-6">
						<input type="email" class="form_bor_bot" id="email" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="Cname">Company Name :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot" id="Cname">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="Address">Address :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot" id="Address" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="Zip">Zip Code :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot" id="Zip">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="City">City :</label>
					<div class="col-sm-6">
						<input type="text" class="form_bor_bot" id="City" required>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-3" for="Software">Software Products :</label>
					<div class="col-sm-6">
						<textarea type="text" class="form_bor_bot" id="Software" required> </textarea>
					</div>
				</div>
				<div class="form-group">        
				  <div class="col-sm-12 text-center">
					<button type="submit" class="btn btn_orange">Submit</button>
				  </div>
				</div>
			 </form>
		</div>
	</div>
</div>