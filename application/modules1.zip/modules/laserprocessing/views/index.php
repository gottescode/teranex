<!-- <div class="section"  style="background-image: url('<?php echo $theme_url?>/images/consumables.jpg');background-repeat: no-repeat;
    background-size: 100% 100%;margin-top: 80px;">
    <div class="container">
		<h1>TERANEX, 3D Printing Service</h1>
		<div class="clearfix"></div>
	</div>
</div> -->
<style type="text/css">
	.bnr_txt{
		text-align: center;
		color: #fff;
		position: absolute;
		top: 40%;
		left: 35%;
	}
</style>
<div class="" style="margin-top: 80px;">
    <!-- <img class="img-responsive bnr-images" src="<?php echo $theme_url?>/images/groupbuying.jpg" alt=""> -->
    <div class="" style="background: url('<?php echo $theme_url?>/images/groupbuying.jpg') center center;background-size: cover;min-height: 450px;">
    	<h1 class="bnr_txt">TERANEX, 3D Printing Service</h1>
    </div>
		
</div><br/>