<?php 
$route['(?i)customer/Customer.php'] = 'customer/phpchat';
?>