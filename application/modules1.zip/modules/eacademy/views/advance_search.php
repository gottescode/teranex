 
<div class="container">
<center>
<h1>Advance Search</h1>
</center>
<div class="col-sm-offset-4 col-sm-4">
	<form class="form-horizontal" name="#" id="#" method="post" action="#">
	  <div class="form-group ">
		  <input type="text" class="form-control input-form" id="#" name="#" placeholder="Keywords">
	  </div>
	  <div class="form-group">
			<select name="Country" id="Country" class="form-control input-form">
				<option value="">Topic</option>
				<option value="A">A</option>
				<option value="B">B</option>
			</select>
	  </div>
	  <div class="form-group">
			<select name="Country" id="Country" class="form-control input-form">
				<option value="">Level</option>
				<option value="A">A</option>
				<option value="B">B</option>
			</select>
	  </div>
	  <div class="form-group">
			<select name="Country" id="Country" class="form-control input-form">
				<option value="">Training Type</option>
				<option value="A">A</option>
				<option value="B">B</option>
			</select>
	  </div>
	  <div class="form-group">
		  <input type="submit" name="btnSearch" id="submit" class="btn input-form adv-search form-control" value="Search" />
	  </div>
	</form>
</div>
 