<div class="container-fluid gray-bg">
	<div class="container allcourse">
		<h1>Courses in Machine Operation</h1>
		  <div class="col-sm-3">
			<div class="courses-section">
				<img class="img-responsive"  src="<?php echo $theme_url?>/images/cb1.jpg" alt="...">
				<span>
				  <h3>Machine Operation</h3>
				  <p>At Teranex, we provide both live and structured training courses.</p>
				</span>
				<a href="#" target="_blank" class="btn">Learn more ></a>
			</div>
		</div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/expert.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
		  </div>
		  </div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/liveStream.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
		  </div>
		  </div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/ser1.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
		 </div>
		  </div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/ser2.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
			</div>
		 </div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/ser1.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
		 </div>
		  </div>
		  <div class="col-sm-3">
			<div class="courses-section">
			<img class="img-responsive"  src="<?php echo $theme_url?>/images/ser2.jpg" alt="...">
			<span>
			  <h3>Machine Operation</h3>
			  <p>At Teranex, we provide both live and structured training courses.</p>
			</span>
			<a href="#" target="_blank" class="btn">Learn more ></a>
			</div>
		 </div>
		  <div class="col-sm-3">
				<div class="courses-section">
				<img class="img-responsive"  src="<?php echo $theme_url?>/images/ser3.jpg" alt="...">
				<span>
				  <h3>Machine Operation</h3>
				  <p>At Teranex, we provide both live and structured training courses.</p>
				</span>
				<a href="#" target="_blank" class="btn">Learn more ></a>
			  </div>
		  </div>
	</div>
</div>