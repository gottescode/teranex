<div class="col-sm-offset-1 col-sm-10">
		<h1>Meet Some of Your Trainers	</h1>
		<div class="col-sm-12">
			<div class="col-sm-3">
				<div class="user-details">
					<div class="user-image">
						<img src="<?php echo $theme_url?>/images/meet-img1.jpg" class="img-rounded img-responsive">
					</div>
					<div class="user-info-block">
						<div class="user-heading">
							<h3>Amit Das</h3>
							<span class="help-block">CAD/CAD Instructor</span>
							<p>Amit has worked as a team leader for a digital company since 2007 and has made innovative progress within the industry. </p>
							<p class="lern mar-20-btm"><a href="#" target="_blank" >View Details ></a></p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3">
				<div class="user-details">
					<div class="user-image">
						<img src="<?php echo $theme_url?>/images/meet-img1.jpg" class="img-rounded img-responsive">
					</div>
					<div class="user-info-block">
						<div class="user-heading">
							<h3>Amit Das</h3>
							<span class="help-block">CAD/CAD Instructor</span>
							<p>Amit has worked as a team leader for a digital company since 2007 and has made innovative progress within the industry. </p>
							<p class="lern mar-20-btm"><a href="#" target="_blank" >View Details ></a></p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3">
				<div class="user-details">
					<div class="user-image">
						<img src="<?php echo $theme_url?>/images/meet-img1.jpg" class="img-rounded img-responsive">
					</div>
					<div class="user-info-block">
						<div class="user-heading">
							<h3>Amit Das</h3>
							<span class="help-block">CAD/CAD Instructor</span>
							<p>Amit has worked as a team leader for a digital company since 2007 and has made innovative progress within the industry. </p>
							<p class="lern mar-20-btm"><a href="#" target="_blank" >View Details ></a></p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3">
				<div class="user-details">
					<div class="user-image">
						<img src="<?php echo $theme_url?>/images/meet-img1.jpg" class="img-rounded img-responsive">
					</div>
					<div class="user-info-block">
						<div class="user-heading">
							<h3>Amit Das</h3>
							<span class="help-block">CAD/CAD Instructor</span>
							<p>Amit has worked as a team leader for a digital company since 2007 and has made innovative progress within the industry. </p>
							<p class="lern mar-20-btm"><a href="#" target="_blank" >View Details ></a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
